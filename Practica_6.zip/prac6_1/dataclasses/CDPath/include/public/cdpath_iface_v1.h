/*
 * cdpath_iface_v1.h
 *
 *  Created on: May 15, 2016
 *      Author: user
 */

#ifndef CDPATH_IFACE_V1_H_
#define CDPATH_IFACE_V1_H_

#include <public/cdpath.h>

#endif /* CDPATH_IFACE_V1_H_ */
