/*
 * random.h
 *
 *  Created on: May 4, 2013
 *      Author: user
 */

#ifndef RANDOM_H_
#define RANDOM_H_

#include <public/basic_types.h>

uint32_t get_random_uint32(uint32_t max);


float get_random_float(float max_module);


#endif /* RANDOM_H_ */
